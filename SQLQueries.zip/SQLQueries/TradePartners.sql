use commodities;
with export_table as (select
Crop, Country, round(sum(Export_USD),1) as Total_Exports
from commodities.importexport
where Period between '2019-09-01' and '2024-08-01'
and Crop='Rice'
group by Crop, Country
order by Total_Exports desc
limit 5)
, import_table as (select
Crop, Country, round(sum(Import_USD),1) as Total_Imports
from commodities.importexport
where Period between '2019-09-01' and '2024-08-01'
and Crop='Almond'
group by Crop, Country
order by Total_Imports desc
limit 5)
select 'Import Partners' as TYPE_, Crop, Country, Total_Imports
from import_table
union all
select 'Export Partners'as TYPE_, Crop, Country, Total_Exports
from export_table