use commodities;
with export_table as (select
Crop, sum(Export_USD) as Total_Exports
from commodities.importexport
where Period between '2019-09-01' and '2024-08-01'
group by Crop
order by Total_Exports desc
limit 3
)
, import_table as (select
Crop, sum(Import_USD) as Total_Imports
from commodities.importexport
where Period between '2019-09-01' and '2024-08-01'
group by Crop
order by Total_Imports desc
limit 3
)
select 'Import Crop', Crop, Total_Imports
from import_table
union all

select 'Export Crop', Crop, Total_Exports
from export_table