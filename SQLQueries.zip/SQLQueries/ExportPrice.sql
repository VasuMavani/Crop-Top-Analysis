use commodities;
SELECT
case when importexport.Period BETWEEN '2019-09-01' AND '2020-08-01' then '2019-20'
when importexport.Period BETWEEN '2020-09-01' AND '2021-08-01' then '2020-21'
when importexport.Period BETWEEN '2021-09-01' AND '2022-08-01' then '2021-22'
when importexport.Period BETWEEN '2022-09-01' AND '2023-08-01' then '2022-23'
when importexport.Period BETWEEN '2023-09-01' AND '2024-08-01' then '2023-24'
else null end AS Time_Period,
importexport.Crop,
importexport.Country,
round((SUM(Export_USD)*pow(10,8))/SUM(Export_Quantity),1) AS Export_Price_per_Qunital
FROM importexport
WHERE importexport.Crop='Gram'
GROUP BY case when importexport.Period BETWEEN '2019-09-01' AND '2020-08-01' then '2019-20'
when importexport.Period BETWEEN '2020-09-01' AND '2021-08-01' then '2020-21'
when importexport.Period BETWEEN '2021-09-01' AND '2022-08-01' then '2021-22'
when importexport.Period BETWEEN '2022-09-01' AND '2023-08-01' then '2022-23'
when importexport.Period BETWEEN '2023-09-01' AND '2024-08-01' then '2023-24'
else null end,
importexport.Crop,
importexport.Country
order by Time_Period asc, Export_Price_per_Qunital DESC