use commodities;
set @crop_name='Wheat';
SELECT
case when Period BETWEEN '2019-09-01' AND '2020-08-01' then '2019-20'
when Period BETWEEN '2020-09-01' AND '2021-08-01' then '2020-21'
when Period BETWEEN '2021-09-01' AND '2022-08-01' then '2021-22'
when Period BETWEEN '2022-09-01' AND '2023-08-01' then '2022-23'
when Period BETWEEN '2023-09-01' AND '2024-08-01' then '2023-24'
else null end as Time_Period,
Crop,
ROUND(SUM(Export_USD),1) AS Total_Export_Value,
ROUND(SUM(Export_Quantity),1) AS Total_Export_Quantity,
ROUND(SUM(Import_USD),1) AS Total_Import_Value,
ROUND(SUM(Import_Quantity),1) AS Total_Import_Quantity,
ROUND(sum(Export_USD) - sum(Import_USD), 1) AS Trade_Balance
FROM importexport

GROUP BY case when Period BETWEEN '2019-09-01' AND '2020-08-01' then '2019-20'
when Period BETWEEN '2020-09-01' AND '2021-08-01' then '2020-21'
when Period BETWEEN '2021-09-01' AND '2022-08-01' then '2021-22'
when Period BETWEEN '2022-09-01' AND '2023-08-01' then '2022-23'
when Period BETWEEN '2023-09-01' AND '2024-08-01' then '2023-24'
else null end, Crop
HAVING crop like @crop_name