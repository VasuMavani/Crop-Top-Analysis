use commodities;
with exchange_Rate_Table as (select distinct importexport.Period,
case when importexport.Period BETWEEN '2019-09-01' AND '2020-08-01' then 75.333
when importexport.Period BETWEEN '2020-09-01' AND '2021-08-01' then 73.137
when importexport.Period BETWEEN '2021-09-01' AND '2022-08-01' then 75.901
when importexport.Period BETWEEN '2022-09-01' AND '2023-08-01' then 82.160
when importexport.Period BETWEEN '2023-09-01' AND '2024-08-01' then 83.350
else null end as XCHNG_RATE from importexport)
SELECT
case when importexport.Period BETWEEN '2019-09-01' AND '2020-08-01' then '2019-20'
when importexport.Period BETWEEN '2020-09-01' AND '2021-08-01' then '2020-21'
when importexport.Period BETWEEN '2021-09-01' AND '2022-08-01' then '2021-22'
when importexport.Period BETWEEN '2022-09-01' AND '2023-08-01' then '2022-23'
when importexport.Period BETWEEN '2023-09-01' AND '2024-08-01' then '2023-24'
else null end as Time_Period,
pricearrivals.Crop,
(SUM(Export_USD)*pow(10,8))/SUM(Export_Quantity) AS Export_Price_per_Qunital,
(SUM(Import_USD)*pow(10,8))/SUM(Import_Quantity) AS Import_Price_per_Qunital,
AVG(pricearrivals.Price)/XCHNG_RATE

FROM importexport INNER JOIN pricearrivals
ON pricearrivals.Period = importexport.Period AND pricearrivals.Crop = importexport.Crop
inner join exchange_Rate_Table on exchange_Rate_Table.Period=importexport.Period
GROUP BY case when importexport.Period BETWEEN '2019-09-01' AND '2020-08-01' then '2019-20'
when importexport.Period BETWEEN '2020-09-01' AND '2021-08-01' then '2020-21'
when importexport.Period BETWEEN '2021-09-01' AND '2022-08-01' then '2021-22'
when importexport.Period BETWEEN '2022-09-01' AND '2023-08-01' then '2022-23'
when importexport.Period BETWEEN '2023-09-01' AND '2024-08-01' then '2023-24'
else null end, pricearrivals.Crop, XCHNG_RATE